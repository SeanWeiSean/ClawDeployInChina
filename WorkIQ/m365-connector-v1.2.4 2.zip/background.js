import { TokenManager } from "./lib/token-manager.js";
import { SearchApi } from "./lib/search-api.js";
import { ContentReader } from "./lib/content-reader.js";
import {
  GraphTokenProvider,
  GRAPH_EXPLORER_PRIMARY_URL,
  GRAPH_TOKEN_REFRESH_ALARM,
  isGraphExplorerUrl
} from "./lib/graph-token-provider.js";
import { WsClient } from "./lib/ws-client.js";
import { HistoryStore } from "./lib/history-store.js";

const WS_PORT_KEY = "m365c.wsPort.v1";
const HEALTH_ALARM_NAME = "m365c-health-check";
const REFRESH_URL = "https://m365.cloud.microsoft/search";

const tokenManager = new TokenManager();
const graphTokenProvider = new GraphTokenProvider();
const contentReader = new ContentReader(graphTokenProvider);
const searchApi = new SearchApi(tokenManager);
const historyStore = new HistoryStore();

const runtimeState = {
  lastActivityAt: null,
  lastSearchQuery: ""
};

function asObject(value) {
  if (!value || typeof value !== "object") {
    return {};
  }
  return value;
}

function deriveResponseSummary(tool, data) {
  if (!data || typeof data !== "object") {
    return {};
  }

  switch (tool) {
    case "search":
      return { resultCount: Array.isArray(data.results) ? data.results.length : 0 };
    case "open":
      return { completeness: data.completeness };
    case "whoami":
      return {
        displayName: String(data.displayName || ""),
        email: String(data.mail || data.userPrincipalName || ""),
        directReportsCount:
          typeof data.directReportsCount === "number" ? data.directReportsCount : undefined
      };
    case "find_people":
      return { resultCount: Array.isArray(data.results) ? data.results.length : 0 };
    case "count_people":
      return { count: data.count };
    default:
      return {};
  }
}

function summarizeRequest(tool, request) {
  const req = asObject(request);
  switch (tool) {
    case "search":
      return { query: req.query, source: req.source, size: req.size, from: req.from };
    case "open": {
      // Strip large fields (summary can be 12KB+) from context for lightweight display.
      const ctx = asObject(req.context);
      return { context: { type: ctx.type, title: ctx.title, id: ctx.id, url: ctx.url } };
    }
    case "whoami":
      return {};
    case "find_people":
      return {
        query: req.query,
        alias: req.alias,
        principalName: req.principal_name || req.principalName,
        displayName: req.display_name || req.displayName,
        department: req.department,
        office: req.office,
        title: req.title,
        size: req.size,
        include_direct_reports: req.include_direct_reports
      };
    case "count_people":
      return {
        query: req.query,
        alias: req.alias,
        principalName: req.principal_name || req.principalName,
        displayName: req.display_name || req.displayName,
        department: req.department,
        office: req.office,
        title: req.title
      };
    default:
      return req;
  }
}

function toHistoryEntrySummary(entry) {
  const item = asObject(entry);
  const response = asObject(item.response);
  const summaryResponse = { success: Boolean(response.success) };
  if (!summaryResponse.success && response.error) {
    summaryResponse.error = String(response.error);
  }

  return {
    id: String(item.id || ""),
    conversationId: String(item.conversationId || ""),
    tool: String(item.tool || ""),
    timestamp: Number(item.timestamp || 0),
    request: summarizeRequest(item.tool, item.request),
    response: summaryResponse,
    responseSummary: asObject(item.responseSummary)
  };
}

async function appendHistorySafely(entry) {
  try {
    await historyStore.append(entry);
  } catch (err) {
    console.warn("[m365connector] failed to append history entry:", err);
  }
}

async function getConfiguredPort() {
  const data = await chrome.storage.local.get(WS_PORT_KEY);
  const value = Number(data[WS_PORT_KEY]);
  if (Number.isInteger(value) && value > 0 && value < 65536) {
    return value;
  }
  return 52365;
}

async function collectStatus(wsStatusOverride = null) {
  const wsStatus = wsStatusOverride || (wsClient ? wsClient.getStatus() : { state: "Disconnected" });
  const graphStatus = await graphTokenProvider.getStatus();

  // Show a badge on the extension icon when Graph sign-in is required.
  try {
    if (graphStatus.state === "sign_in_required") {
      await chrome.action.setBadgeText({ text: "!" });
      await chrome.action.setBadgeBackgroundColor({ color: "#aa2430" });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  } catch (_err) {
    // Ignore; action API may not be available in tests.
  }

  return {
    websocket: wsStatus,
    tokens: tokenManager.getStatus(),
    graph: graphStatus,
    lastActivityAt: runtimeState.lastActivityAt,
    lastSearchQuery: runtimeState.lastSearchQuery
  };
}

async function onWsRequest(type, params) {
  runtimeState.lastActivityAt = Date.now();

  if (type === "get_status") {
    return collectStatus();
  }

  if (!["search", "open", "whoami", "find_people", "count_people"].includes(type)) {
    throw new Error(`Unknown request type: ${type}`);
  }

  const requestParams = { ...asObject(params) };
  const conversationId = String(requestParams.conversation_id || "").trim();
  if (!conversationId) {
    throw new Error("conversation_id is required");
  }
  delete requestParams.conversation_id;

  switch (type) {
    case "search": {
      try {
        const response = await searchApi.search(requestParams);
        runtimeState.lastSearchQuery = String(requestParams.query || "");
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: true, data: response },
          responseSummary: deriveResponseSummary(type, response)
        });
        return response;
      } catch (err) {
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: false, error: String(err?.message || err) },
          responseSummary: {}
        });
        throw err;
      }
    }

    case "open": {
      try {
        const response = await contentReader.read(requestParams);
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: true, data: response },
          responseSummary: deriveResponseSummary(type, response)
        });
        return response;
      } catch (err) {
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: false, error: String(err?.message || err) },
          responseSummary: {}
        });
        throw err;
      }
    }

    case "whoami": {
      try {
        const response = await contentReader.whoAmI({
          directReportsSize: requestParams.direct_reports_size
        });
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: true, data: response },
          responseSummary: deriveResponseSummary(type, response)
        });
        return response;
      } catch (err) {
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: false, error: String(err?.message || err) },
          responseSummary: {}
        });
        throw err;
      }
    }

    case "find_people": {
      try {
        const response = await contentReader.findPeople(requestParams);
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: true, data: response },
          responseSummary: deriveResponseSummary(type, response)
        });
        return response;
      } catch (err) {
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: false, error: String(err?.message || err) },
          responseSummary: {}
        });
        throw err;
      }
    }

    case "count_people": {
      try {
        const response = await contentReader.countPeople(requestParams);
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: true, data: response },
          responseSummary: deriveResponseSummary(type, response)
        });
        return response;
      } catch (err) {
        await appendHistorySafely({
          conversationId,
          tool: type,
          request: requestParams,
          response: { success: false, error: String(err?.message || err) },
          responseSummary: {}
        });
        throw err;
      }
    }
  }
}

let wsClient = null;
let initPromise = null;

async function setupWsClient() {
  const port = await getConfiguredPort();

  wsClient = new WsClient({
    port,
    onRequest: onWsRequest,
    onStatusChange: (_status) => {
      // Popup polls status via runtime message; no push channel needed here.
    }
  });
}

async function ensureConnected(reason) {
  // Wait for init() to finish setting up wsClient before attempting to connect.
  if (initPromise) {
    await initPromise;
  }
  if (!wsClient) {
    await setupWsClient();
  }
  await wsClient.connectOnWake(reason);
}

function waitForTabLoad(tabId, maxWaitMs) {
  return new Promise((resolve) => {
    const deadline = Date.now() + maxWaitMs;
    let settled = false;

    const finish = (reason) => {
      if (settled) {
        return;
      }
      settled = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      console.log("[m365connector] waitForTabLoad: tab %d resolved (%s)", tabId, reason);
      resolve();
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        finish("complete");
      }
    };

    chrome.tabs.onUpdated.addListener(onUpdated);

    setTimeout(() => {
      finish(Date.now() >= deadline ? "timeout" : "timer");
    }, maxWaitMs);

    chrome.tabs.get(tabId).then((tab) => {
      if (tab?.status === "complete") {
        finish("already-complete");
      }
    }).catch((err) => {
      console.warn("[m365connector] waitForTabLoad: failed to read tab %d:", tabId, err);
      finish("tab-get-failed");
    });
  });
}

async function openTabAndWaitForToken(url, { maxWaitMs = 20000 } = {}) {
  let tab;
  const startedAt = Date.now();
  try {
    console.log("[m365connector] openTabAndWaitForToken: opening %s", url);
    tab = await chrome.tabs.create({ url, active: false });
    console.log("[m365connector] openTabAndWaitForToken: opened tab %d", tab.id);

    await waitForTabLoad(tab.id, maxWaitMs);

    const elapsed = Date.now() - startedAt;
    const remaining = maxWaitMs - elapsed;
    const pollDuration = Math.min(10000, Math.max(0, remaining));
    console.log("[m365connector] openTabAndWaitForToken: polling for up to %dms", pollDuration);
    const pollEnd = Date.now() + pollDuration;
    const POLL_MS = 250;
    while (Date.now() < pollEnd) {
      if (!tokenManager.needsRefresh()) {
        console.log(
          "[m365connector] openTabAndWaitForToken: token ready after %dms",
          Date.now() - startedAt
        );
        return true;
      }
      await new Promise((r) => setTimeout(r, POLL_MS));
    }

    console.log(
      "[m365connector] openTabAndWaitForToken: no token captured within %dms",
      Date.now() - startedAt
    );
    return false;
  } finally {
    if (tab?.id) {
      console.log("[m365connector] openTabAndWaitForToken: closing tab %d", tab.id);
      try { await chrome.tabs.remove(tab.id); } catch (_e) { /* tab may already be closed */ }
    }
  }
}

let refreshSubstratePromise = null;

async function refreshSubstrateToken({ force = false } = {}) {
  if (refreshSubstratePromise) {
    console.log("[m365connector] substrate refresh: reusing in-flight refresh");
    return refreshSubstratePromise;
  }

  refreshSubstratePromise = (async () => {
    if (!force && !tokenManager.needsRefresh()) {
      console.log("[m365connector] substrate refresh: skipped, token still valid");
      return true;
    }

    if (!force && tokenManager.isRefreshCooldownActive()) {
      const remainingMs = Math.max(
        tokenManager.getRefreshCooldownMs() - (Date.now() - tokenManager.lastRefreshFailedAt),
        0
      );
      console.log(
        "[m365connector] substrate refresh: cooldown active (%d failures, retry in %ds)",
        tokenManager.refreshFailCount,
        Math.ceil(remainingMs / 1000)
      );
      return false;
    }

    tokenManager.markRefreshStarted();
    console.log("[m365connector] substrate refresh: starting%s", force ? " (forced)" : "");

    try {
      const refreshSuccess = await openTabAndWaitForToken(REFRESH_URL, { maxWaitMs: 20000 });
      if (refreshSuccess) {
        if (tokenManager.refreshFailCount > 0) {
          console.log(
            "[m365connector] substrate refresh: recovered after %d failures",
            tokenManager.refreshFailCount
          );
        }
        tokenManager.markRefreshSuccess();
        console.log("[m365connector] substrate refresh: success");
      } else {
        tokenManager.markRefreshFailed();
        console.warn("[m365connector] substrate refresh: completed without capturing a token");
      }
      return refreshSuccess;
    } catch (err) {
      tokenManager.markRefreshFailed();
      console.warn("[m365connector] substrate refresh: failed:", err);
      return false;
    }
  })();

  try {
    return await refreshSubstratePromise;
  } finally {
    refreshSubstratePromise = null;
  }
}

async function refreshTokensInBrowser() {
  return refreshSubstrateToken({ force: true });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
      case "m365c_get_status": {
        sendResponse({ ok: true, data: await collectStatus() });
        return;
      }

      case "m365c_set_ws_port": {
        const port = Number(message.port);
        if (!Number.isInteger(port) || port <= 0 || port >= 65536) {
          throw new Error("Invalid port");
        }

        await chrome.storage.local.set({ [WS_PORT_KEY]: port });

        if (wsClient) {
          await wsClient.stop();
          await setupWsClient();
          await wsClient.connectOnWake("port-updated");
        }

        sendResponse({ ok: true, data: await collectStatus() });
        return;
      }

      case "m365c_refresh_tokens": {
        const refreshSuccess = await refreshTokensInBrowser();
        sendResponse({ ok: true, refreshSuccess, data: await collectStatus() });
        return;
      }

      case "m365c_set_graph_enabled": {
        const enabled = Boolean(message.enabled);
        await graphTokenProvider.setEnabled(enabled, { interactive: enabled });
        sendResponse({ ok: true, data: await collectStatus() });
        return;
      }

      case "m365c_refresh_graph_token": {
        await graphTokenProvider.refresh({ force: true });
        sendResponse({ ok: true, data: await collectStatus() });
        return;
      }

      case "m365c_open_m365_search": {
        // Open M365 search as an active (visible) tab so the user can sign in
        // and the webRequest listener can capture the Substrate token.
        await chrome.tabs.create({ url: REFRESH_URL, active: true });
        sendResponse({ ok: true });
        return;
      }

      case "m365c_open_graph_explorer": {
        // Focus the provider tab so the user can sign in.
        const tabId = graphTokenProvider.tabId;
        if (tabId) {
          try {
            const tab = await chrome.tabs.get(tabId);
            if (isGraphExplorerUrl(tab?.url)) {
              // Tab is still on Graph Explorer — just focus it.
              await chrome.tabs.update(tabId, { active: true });
            } else {
              // Tab navigated away — bring it back to Graph Explorer.
              await chrome.tabs.update(tabId, { url: GRAPH_EXPLORER_PRIMARY_URL, active: true });
            }
            if (tab?.windowId) {
              await chrome.windows.update(tab.windowId, { focused: true });
            }
          } catch (_err) {
            // Tab may have been closed; open a new one.
            const newTab = await chrome.tabs.create({ url: GRAPH_EXPLORER_PRIMARY_URL, active: true });
            graphTokenProvider.tabId = newTab.id;
            graphTokenProvider.openedByProvider = true;
            await graphTokenProvider.persistTabId();
          }
        } else {
          const newTab = await chrome.tabs.create({ url: GRAPH_EXPLORER_PRIMARY_URL, active: true });
          graphTokenProvider.tabId = newTab.id;
          graphTokenProvider.openedByProvider = true;
          await graphTokenProvider.persistTabId();
        }
        sendResponse({ ok: true });
        graphTokenProvider.startSignInWatch();
        return;
      }

      case "m365c_get_history_summary": {
        const [totalRequests, conversations] = await Promise.all([
          historyStore.count(),
          historyStore.getConversations()
        ]);
        sendResponse({
          ok: true,
          data: {
            totalRequests,
            conversationCount: conversations.length
          }
        });
        return;
      }

      case "m365c_get_conversations": {
        const conversations = await historyStore.getConversations();
        sendResponse({ ok: true, data: conversations });
        return;
      }

      case "m365c_get_conversation_entries": {
        const conversationId = String(message.conversationId || "").trim();
        if (!conversationId) {
          throw new Error("conversationId is required");
        }
        const entries = await historyStore.getByConversation(conversationId);
        sendResponse({ ok: true, data: entries.map((entry) => toHistoryEntrySummary(entry)) });
        return;
      }

      case "m365c_get_entry_detail": {
        const entryId = String(message.entryId || "").trim();
        if (!entryId) {
          throw new Error("entryId is required");
        }
        const entry = await historyStore.getById(entryId);
        if (!entry) {
          throw new Error("History entry not found");
        }
        sendResponse({ ok: true, data: entry });
        return;
      }

      case "m365c_clear_history": {
        await historyStore.clear();
        sendResponse({ ok: true });
        return;
      }

      default:
        sendResponse({ ok: false, error: `Unknown runtime message: ${message?.type}` });
    }
  })().catch((err) => {
    sendResponse({ ok: false, error: String(err?.message || err) });
  });

  return true;
});

// When the user grants the optional developer.microsoft.com permission
// (which closes the popup before setGraphEnabled can run), auto-enable Graph.
chrome.permissions.onAdded.addListener((permissions) => {
  const origins = permissions.origins || [];
  if (origins.some((o) => o.includes("developer.microsoft.com"))) {
    graphTokenProvider.setEnabled(true, { interactive: true }).catch((err) => {
      console.warn("[m365connector] auto-enable graph after permission grant failed:", err);
    });
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(HEALTH_ALARM_NAME, {
    periodInMinutes: 0.5
  });
  chrome.alarms.create(GRAPH_TOKEN_REFRESH_ALARM, {
    periodInMinutes: 1
  });

  ensureConnected("onInstalled").catch((err) => {
    console.warn("[m365connector] initial connect failed:", err);
  });
});

chrome.runtime.onStartup.addListener(() => {
  ensureConnected("onStartup").catch((err) => {
    console.warn("[m365connector] startup connect failed:", err);
  });
});

async function autoRefreshTokens() {
  return refreshSubstrateToken();
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === GRAPH_TOKEN_REFRESH_ALARM) {
    graphTokenProvider.onAlarm(alarm.name).catch((err) => {
      console.warn("[m365connector] graph token refresh failed:", err);
    });
    return;
  }

  if (alarm.name !== HEALTH_ALARM_NAME) {
    return;
  }

  tokenManager.cleanupExpired().catch((err) => {
    console.warn("[m365connector] token cleanup failed:", err);
  });

  ensureConnected("alarm").catch((_err) => {
    // Reconnect failures are expected when MCP server is not running.
  });

  autoRefreshTokens().catch((err) => {
    console.warn("[m365connector] auto-refresh check failed:", err);
  });
});

async function init() {
  await tokenManager.init();
  await historyStore.open();

  // Ensure alarm exists in case extension restarted without onInstalled firing.
  chrome.alarms.create(HEALTH_ALARM_NAME, {
    periodInMinutes: 0.5
  });
  chrome.alarms.create(GRAPH_TOKEN_REFRESH_ALARM, {
    periodInMinutes: 1
  });

  // Set up WebSocket first — it's critical for MCP communication.
  // Graph token init is optional and may be slow (DOM extraction, polling).
  await setupWsClient();
  await wsClient.connectOnWake("service-worker-start");

  // Graph init runs after WebSocket is ready so it doesn't block MCP.
  graphTokenProvider.init({ interactive: false }).catch((err) => {
    console.warn("[m365connector] graph token init failed:", err);
  });

  // Capture tokens on startup if missing.
  autoRefreshTokens().catch((_err) => {});
}

initPromise = init().catch((err) => {
  console.error("[m365connector] background initialization failed:", err);
});

// Debug helpers — accessible from service worker console via globalThis.m365c
globalThis.m365c = {
  tokenManager,
  graphTokenProvider,
  refreshSubstrate: (opts) => refreshSubstrateToken(opts),
  status: () => collectStatus(),
};
