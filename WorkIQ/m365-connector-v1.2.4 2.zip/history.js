function $(id) {
  return document.getElementById(id);
}

async function sendMessage(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) {
    throw new Error(response?.error || "Unknown error");
  }
  return response.data;
}

function truncateConversationId(value, maxLength = 20) {
  const id = String(value || "");
  if (id.length <= maxLength) {
    return id;
  }
  return `${id.slice(0, 10)}...${id.slice(-7)}`;
}

function formatDateTime(value) {
  if (!value) {
    return "-";
  }
  return new Date(value).toLocaleString();
}

function pluralize(count, singular, plural) {
  return count === 1 ? singular : plural;
}

function asObject(value) {
  if (!value || typeof value !== "object") {
    return {};
  }
  return value;
}

function pushLineIfPresent(lines, key, value) {
  if (value === null || value === undefined || value === "") {
    return;
  }
  lines.push({ key, value: String(value) });
}

function requestSummaryLines(entry) {
  const request = asObject(entry.request);
  switch (entry.tool) {
    case "search":
      return [
        { key: "Query", value: String(request.query || "-") },
        { key: "Source", value: String(request.source || "all") }
      ];
    case "open": {
      const ctx = asObject(request.context);
      const lines = [];
      if (ctx.title) {
        lines.push({ key: "Title", value: String(ctx.title) });
      }
      if (ctx.type) {
        lines.push({ key: "Type", value: String(ctx.type) });
      }
      if (!lines.length) {
        lines.push({ key: "Item", value: "(details in full response)" });
      }
      return lines;
    }
    case "whoami":
      return [{ key: "Operation", value: "Current user profile lookup" }];
    case "find_people": {
      const lines = [];
      pushLineIfPresent(lines, "Query", request.query);
      pushLineIfPresent(lines, "Alias", request.alias);
      pushLineIfPresent(lines, "Principal Name", request.principalName);
      pushLineIfPresent(lines, "Display Name", request.displayName);
      pushLineIfPresent(lines, "Department", request.department);
      pushLineIfPresent(lines, "Office", request.office);
      pushLineIfPresent(lines, "Title", request.title);
      if (typeof request.include_direct_reports === "boolean") {
        lines.push({
          key: "Include Direct Reports",
          value: request.include_direct_reports ? "Yes" : "No"
        });
      }
      lines.push({ key: "Size", value: String(request.size || 20) });
      return lines;
    }
    case "count_people": {
      const lines = [];
      pushLineIfPresent(lines, "Query", request.query);
      pushLineIfPresent(lines, "Alias", request.alias);
      pushLineIfPresent(lines, "Principal Name", request.principalName);
      pushLineIfPresent(lines, "Display Name", request.displayName);
      pushLineIfPresent(lines, "Department", request.department);
      pushLineIfPresent(lines, "Office", request.office);
      pushLineIfPresent(lines, "Title", request.title);
      return lines;
    }
    default:
      return [{ key: "Request", value: JSON.stringify(request) }];
  }
}

function responseSummaryLines(entry) {
  const summary = asObject(entry.responseSummary);
  switch (entry.tool) {
    case "search":
      return [{ key: "Result Count", value: String(summary.resultCount ?? 0) }];
    case "open":
      return [{ key: "Completeness", value: String(summary.completeness || "-") }];
    case "whoami":
      return [
        { key: "Display Name", value: String(summary.displayName || "-") },
        { key: "Email", value: String(summary.email || "-") },
        {
          key: "Direct Reports",
          value: typeof summary.directReportsCount === "number"
            ? String(summary.directReportsCount)
            : "-"
        }
      ];
    case "find_people":
      return [{ key: "Result Count", value: String(summary.resultCount ?? 0) }];
    case "count_people":
      return [{ key: "Count", value: String(summary.count ?? 0) }];
    default:
      return [];
  }
}

function createLine(key, value) {
  const line = document.createElement("p");
  line.className = "line";

  const keyNode = document.createElement("span");
  keyNode.className = "key";
  keyNode.textContent = `${key}:`;

  const valueNode = document.createElement("span");
  valueNode.textContent = value;

  line.append(keyNode, valueNode);
  return line;
}

function createStateNode(message, options = {}) {
  const node = document.createElement("p");
  const classes = ["state"];
  if (options.error) {
    classes.push("error");
  }
  if (options.loading) {
    classes.push("loading");
  }
  node.className = classes.join(" ");
  node.textContent = message;

  if (typeof options.onRetry === "function") {
    const retryBtn = document.createElement("button");
    retryBtn.type = "button";
    retryBtn.className = "retryLink";
    retryBtn.textContent = "Retry";
    retryBtn.addEventListener("click", options.onRetry);
    node.append(" ", retryBtn);
  }

  return node;
}

let entryLoadToken = 0;

const state = {
  conversations: [],
  selectedConversationId: null,
  entriesByConversation: new Map(),
  entryDetailById: new Map(),
  loadingConversations: false,
  loadingEntries: false,
  conversationsError: "",
  entriesError: ""
};

function renderConversations() {
  const container = $("conversationList");
  container.innerHTML = "";

  if (state.loadingConversations) {
    container.append(createStateNode("Loading history...", { loading: true }));
    return;
  }

  if (state.conversationsError) {
    container.append(
      createStateNode("Failed to load history.", {
        error: true,
        onRetry: () => {
          loadConversations({ preserveSelection: true }).catch((err) => {
            $("message").textContent = String(err?.message || err);
          });
        }
      })
    );
    return;
  }

  if (!state.conversations.length) {
    container.append(createStateNode("No history yet. Tool invocations will appear here."));
    return;
  }

  for (const conversation of state.conversations) {
    const item = document.createElement("div");
    item.className = "conversationItem";
    if (conversation.conversationId === state.selectedConversationId) {
      item.classList.add("active");
    }

    const info = document.createElement("div");
    const title = document.createElement("div");
    title.className = "conversationId";
    title.textContent = truncateConversationId(conversation.conversationId);
    title.title = conversation.conversationId;

    const meta = document.createElement("div");
    meta.className = "conversationMeta";
    meta.textContent =
      `${conversation.entryCount} ${pluralize(conversation.entryCount, "request", "requests")} · ` +
      formatDateTime(conversation.lastSeen);

    info.append(title, meta);

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "copyBtn";
    copyBtn.textContent = "Copy";
    copyBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      navigator.clipboard.writeText(conversation.conversationId).then(() => {
        $("message").textContent = "Conversation ID copied.";
      }).catch((err) => {
        $("message").textContent = `Copy failed: ${String(err?.message || err)}`;
      });
    });

    item.append(info, copyBtn);
    item.addEventListener("click", () => {
      selectConversation(conversation.conversationId).catch((err) => {
        $("message").textContent = String(err?.message || err);
      });
    });
    container.append(item);
  }
}

function renderDetail() {
  const container = $("detailView");
  container.innerHTML = "";

  if (state.loadingConversations) {
    container.append(createStateNode("Loading history...", { loading: true }));
    return;
  }

  if (state.conversationsError) {
    container.append(
      createStateNode("Failed to load history.", {
        error: true,
        onRetry: () => {
          loadConversations({ preserveSelection: true }).catch((err) => {
            $("message").textContent = String(err?.message || err);
          });
        }
      })
    );
    return;
  }

  if (!state.conversations.length) {
    container.append(createStateNode("No history yet. Tool invocations will appear here."));
    return;
  }

  if (!state.selectedConversationId) {
    container.append(createStateNode("Select a conversation from the sidebar."));
    return;
  }

  if (state.loadingEntries) {
    container.append(createStateNode("Loading conversation entries...", { loading: true }));
    return;
  }

  if (state.entriesError) {
    container.append(
      createStateNode("Failed to load history.", {
        error: true,
        onRetry: () => {
          loadConversationEntries(state.selectedConversationId).catch((err) => {
            $("message").textContent = String(err?.message || err);
          });
        }
      })
    );
    return;
  }

  const entries = state.entriesByConversation.get(state.selectedConversationId) || [];
  const header = document.createElement("div");
  header.className = "detailHeader";

  const title = document.createElement("h3");
  title.className = "detailTitle";
  title.textContent = state.selectedConversationId;
  title.title = state.selectedConversationId;

  const meta = document.createElement("p");
  meta.className = "detailMeta";
  if (entries.length) {
    meta.textContent =
      `${entries.length} ${pluralize(entries.length, "request", "requests")} · ` +
      `${formatDateTime(entries[0].timestamp)} -> ${formatDateTime(entries[entries.length - 1].timestamp)}`;
  } else {
    meta.textContent = "No entries in this conversation.";
  }

  header.append(title, meta);
  container.append(header);

  if (!entries.length) {
    container.append(createStateNode("No entries in this conversation."));
    return;
  }

  const list = document.createElement("div");
  list.className = "entryList";

  for (const entry of entries) {
    const card = document.createElement("article");
    card.className = "entryCard";

    const top = document.createElement("div");
    top.className = "entryTop";

    const time = document.createElement("div");
    time.className = "entryTime";
    time.textContent = formatDateTime(entry.timestamp);

    const tags = document.createElement("div");
    tags.className = "entryTags";

    const toolTag = document.createElement("span");
    toolTag.className = "tag tool";
    toolTag.textContent = entry.tool;

    const statusTag = document.createElement("span");
    statusTag.className = entry.response?.success ? "tag success" : "tag failure";
    statusTag.textContent = entry.response?.success ? "Success" : "Failure";

    tags.append(toolTag, statusTag);
    top.append(time, tags);

    card.append(top);

    for (const line of requestSummaryLines(entry)) {
      card.append(createLine(line.key, line.value));
    }

    for (const line of responseSummaryLines(entry)) {
      card.append(createLine(line.key, line.value));
    }

    if (!entry.response?.success && entry.response?.error) {
      card.append(createLine("Error", String(entry.response.error)));
    }

    const toggleButton = document.createElement("button");
    toggleButton.type = "button";
    toggleButton.className = "inlineBtn";
    toggleButton.textContent = "Show full response";

    const fullResponse = document.createElement("pre");
    fullResponse.className = "fullResponse";
    fullResponse.hidden = true;

    toggleButton.addEventListener("click", () => {
      toggleFullResponse(entry.id, fullResponse, toggleButton).catch((err) => {
        $("message").textContent = `Failed to load full response: ${String(err?.message || err)}`;
      });
    });

    card.append(toggleButton, fullResponse);
    list.append(card);
  }

  container.append(list);
}

function render() {
  renderConversations();
  renderDetail();
}

async function loadConversations(options = {}) {
  const preserveSelection = Boolean(options.preserveSelection);
  state.loadingConversations = true;
  state.conversationsError = "";
  render();

  try {
    const conversations = await sendMessage({ type: "m365c_get_conversations" });
    conversations.sort((a, b) => Number(b.lastSeen || 0) - Number(a.lastSeen || 0));
    state.conversations = conversations;

    if (preserveSelection) {
      const stillExists = conversations.some(
        (item) => item.conversationId === state.selectedConversationId
      );
      if (!stillExists) {
        state.selectedConversationId = null;
      }
    } else {
      state.selectedConversationId = null;
    }
  } catch (err) {
    state.conversations = [];
    state.selectedConversationId = null;
    state.conversationsError = String(err?.message || err);
  } finally {
    state.loadingConversations = false;
    render();
  }
}

async function loadConversationEntries(conversationId) {
  const token = ++entryLoadToken;
  state.loadingEntries = true;
  state.entriesError = "";
  renderDetail();

  try {
    const entries = await sendMessage({
      type: "m365c_get_conversation_entries",
      conversationId
    });
    // Discard stale response if user switched conversations while loading.
    if (token !== entryLoadToken) {
      return;
    }
    entries.sort((a, b) => Number(a.timestamp || 0) - Number(b.timestamp || 0));
    state.entriesByConversation.set(conversationId, entries);
  } catch (err) {
    if (token !== entryLoadToken) {
      return;
    }
    state.entriesByConversation.delete(conversationId);
    state.entriesError = String(err?.message || err);
  } finally {
    if (token === entryLoadToken) {
      state.loadingEntries = false;
      renderDetail();
    }
  }
}

async function selectConversation(conversationId) {
  state.selectedConversationId = conversationId;
  state.entriesError = "";
  render();
  await loadConversationEntries(conversationId);
}

async function toggleFullResponse(entryId, target, button) {
  if (target.dataset.loaded === "true") {
    if (target.hidden) {
      target.hidden = false;
      button.textContent = "Hide full response";
    } else {
      target.hidden = true;
      button.textContent = "Show full response";
    }
    return;
  }

  button.disabled = true;
  button.textContent = "Loading...";
  try {
    let detail = state.entryDetailById.get(entryId);
    if (!detail) {
      detail = await sendMessage({
        type: "m365c_get_entry_detail",
        entryId
      });
      state.entryDetailById.set(entryId, detail);
    }
    target.textContent = JSON.stringify(detail.response, null, 2);
    target.dataset.loaded = "true";
    target.hidden = false;
    button.textContent = "Hide full response";
  } finally {
    button.disabled = false;
  }
}

function wireEvents() {
  $("clearBtn").addEventListener("click", () => {
    if (!confirm("Clear all history? This cannot be undone.")) {
      return;
    }

    sendMessage({ type: "m365c_clear_history" }).then(() => {
      state.entriesByConversation.clear();
      state.entryDetailById.clear();
      state.selectedConversationId = null;
      $("message").textContent = "History cleared.";
      return loadConversations({ preserveSelection: false });
    }).catch((err) => {
      $("message").textContent = `Failed to clear history: ${String(err?.message || err)}`;
    });
  });
}

wireEvents();
loadConversations({ preserveSelection: false }).catch((err) => {
  $("message").textContent = String(err?.message || err);
});
