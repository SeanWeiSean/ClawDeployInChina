function $(id) {
  return document.getElementById(id);
}

let graphToggleSyncInProgress = false;
let graphRefreshing = false;

async function sendMessage(payload) {
  return chrome.runtime.sendMessage(payload);
}

function setBadge(el, text, state) {
  el.textContent = text;
  el.className = `badge ${state}`;
}

function formatLastActivity(value) {
  if (!value) {
    return "-";
  }
  return new Date(value).toLocaleString();
}

function tokenLabel(tokenStatus, refreshState = null) {
  if (!tokenStatus) {
    if (refreshState === "refreshing") {
      return { text: "Refreshing...", color: "yellow" };
    }
    if (refreshState === "session_required") {
      return { text: "Session Required", color: "red" };
    }
    if (refreshState === "refresh_failed") {
      return { text: "Refresh Failed", color: "red" };
    }
    return { text: "Missing", color: "red" };
  }

  switch (tokenStatus.state) {
    case "valid":
      return { text: "Valid", color: "green" };
    case "expiring":
      return { text: "Expiring", color: "yellow" };
    case "expired":
    default:
      if (refreshState === "refreshing") {
        return { text: "Refreshing...", color: "yellow" };
      }
      if (refreshState === "session_required") {
        return { text: "Session Required", color: "red" };
      }
      if (refreshState === "refresh_failed") {
        return { text: "Refresh Failed", color: "red" };
      }
      return {
        text: tokenStatus.state === "expired" ? "Expired" : "Missing",
        color: "red",
      };
  }
}

function graphLabel(graphStatus) {
  const state = String(graphStatus?.state || "missing");
  switch (state) {
    case "valid":
      return { text: "Valid", color: "green" };
    case "expiring":
      return { text: "Expiring", color: "yellow" };
    case "refreshing":
      return { text: "Refreshing...", color: "yellow" };
    case "disabled":
      return { text: "Disabled", color: "red" };
    case "permission_missing":
      return { text: "Permission Required", color: "yellow" };
    case "sign_in_required":
      return { text: "Sign-in Required", color: "red" };
    case "awaiting_sign_in":
      return { text: "Waiting for Sign-in...", color: "yellow" };
    default:
      return { text: "Missing", color: "red" };
  }
}

function wsLabel(ws) {
  const state = String(ws?.state || "Disconnected");
  if (state === "Ready") {
    return { text: "Connected", color: "green" };
  }
  if (state === "Connecting" || state === "Reconnecting") {
    return { text: state, color: "yellow" };
  }
  return { text: "Disconnected", color: "red" };
}

async function refreshStatus() {
  const message = $("message");
  try {
    const [statusResponse, historyResponse] = await Promise.all([
      sendMessage({ type: "m365c_get_status" }),
      sendMessage({ type: "m365c_get_history_summary" })
    ]);

    if (!statusResponse?.ok) {
      throw new Error(statusResponse?.error || "Unknown error");
    }

    const status = statusResponse.data;

    const ws = status?.websocket || {};
    const wsBadge = wsLabel(ws);
    setBadge($("wsState"), wsBadge.text, wsBadge.color);
    $("wsAddress").textContent = ws.url || "ws://127.0.0.1:52365";

    const substrate = tokenLabel(
      status?.tokens?.substrate,
      status?.tokens?.substrateRefreshState
    );
    setBadge($("substrateStatus"), substrate.text, substrate.color);
    $("substrateSignIn").style.display =
      status?.tokens?.substrateRefreshState === "session_required" ? "" : "none";
    const graph = graphLabel(status?.graph);
    if (!graphRefreshing) {
      setBadge($("graphStatus"), graph.text, graph.color);
    }

    const graphEnabled = Boolean(status?.graph?.enabled);
    graphToggleSyncInProgress = true;
    $("graphEnabled").checked = graphEnabled;
    graphToggleSyncInProgress = false;

    $("refreshGraph").style.display = graphEnabled ? "" : "none";

    const graphState = status?.graph?.state;
    $("graphSignIn").style.display = graphState === "sign_in_required" ? "" : "none";

    $("lastQuery").textContent = status?.lastSearchQuery || "-";
    $("lastActivity").textContent = formatLastActivity(status?.lastActivityAt);

    if (historyResponse?.ok) {
      $("historyCount").textContent = String(historyResponse.data?.totalRequests ?? 0);
      $("conversationCount").textContent = String(historyResponse.data?.conversationCount ?? 0);
    } else {
      $("historyCount").textContent = "0";
      $("conversationCount").textContent = "0";
    }

    message.textContent = ws.lastError ? `Last WS error: ${ws.lastError}` : "";
  } catch (err) {
    message.textContent = `Failed to fetch status: ${String(err?.message || err)}`;
  }
}

async function setGraphEnabled(enabled) {
  const response = await sendMessage({ type: "m365c_set_graph_enabled", enabled: Boolean(enabled) });
  if (!response?.ok) {
    throw new Error(response?.error || "Unknown error");
  }
}

function wireEvents() {
  $("refreshSubstrate").addEventListener("click", () => {
    const btn = $("refreshSubstrate");
    btn.disabled = true;
    $("message").textContent = "";
    sendMessage({ type: "m365c_refresh_tokens" })
      .then((resp) => {
        if (!resp?.ok) {
          $("message").textContent = `Substrate refresh failed: ${resp?.error || "Unknown error"}`;
          return;
        }
        if (resp.refreshSuccess === false) {
          $("message").textContent =
            "Token refresh failed. Try opening m365.cloud.microsoft in your browser.";
        }
      })
      .catch((err) => {
        $("message").textContent = `Substrate refresh failed: ${String(err?.message || err)}`;
      })
      .finally(() => {
        btn.disabled = false;
        refreshStatus();
      });
  });

  $("refreshGraph").addEventListener("click", () => {
    const btn = $("refreshGraph");
    btn.disabled = true;
    graphRefreshing = true;
    $("message").textContent = "";
    setBadge($("graphStatus"), "Refreshing...", "yellow");
    sendMessage({ type: "m365c_refresh_graph_token" })
      .then((resp) => {
        if (!resp?.ok) {
          $("message").textContent = `Graph refresh failed: ${resp?.error || "Unknown error"}`;
        }
      })
      .catch((err) => {
        $("message").textContent = `Graph refresh failed: ${String(err?.message || err)}`;
      })
      .finally(() => {
        graphRefreshing = false;
        btn.disabled = false;
        refreshStatus();
      });
  });

  $("graphEnabled").addEventListener("change", () => {
    if (graphToggleSyncInProgress) {
      return;
    }

    (async () => {
      const enabled = $("graphEnabled").checked;
      await setGraphEnabled(enabled);
      await refreshStatus();
      $("message").textContent = enabled
        ? "Graph enhanced reading enabled. Complete Graph Explorer sign-in if prompted."
        : "Graph enhanced reading disabled.";
    })().catch((err) => {
      $("message").textContent = String(err?.message || err);
      graphToggleSyncInProgress = true;
      $("graphEnabled").checked = !$("graphEnabled").checked;
      graphToggleSyncInProgress = false;
    });
  });

  $("graphSignIn").addEventListener("click", () => {
    sendMessage({ type: "m365c_open_graph_explorer" });
  });

  $("substrateSignIn").addEventListener("click", () => {
    sendMessage({ type: "m365c_open_m365_search" });
  });
}

wireEvents();
refreshStatus();
setInterval(refreshStatus, 3000);

// Display extension version from manifest.
const manifest = chrome.runtime.getManifest();
$("version").textContent = `v${manifest.version}`;
